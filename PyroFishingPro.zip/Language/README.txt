If you wish to use a language file here, follow these steps:

- Delete the messages.yml
- Copy and paste your language file into the main directory.
- Rename it to 'messages.yml'
- Restart the server
- Good to go!

If you have a language file that isn't listed with the plugin, please consider translating it
and sending me the translated file so I can include it for other users. 

Note: When the plugin updates, these files will not automatically be updated. These are updated
by the community and it may take a while for the new translations to be added. You can alternatively
translate the new lines yourself if you need to.

Thank you. 

Thanks to:
- Maatev (Polish)
- HuaJiuLi (Chinese)
- n54b & Friirus & Kaiso (French)
- audicu707 (Turkish)